package com.example.curencyexchangebank

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Vinculando los elementos del layout con el código
        val inputAmount = findViewById<EditText>(R.id.editTextSoles)
        val convertButton = findViewById<Button>(R.id.buttonConvertir)
        val resultView = findViewById<TextView>(R.id.textViewResultado)
        val currencySpinner = findViewById<Spinner>(R.id.spinnerDivisas)

        // Configurando el Spinner
        val currencies = arrayOf("Dólares", "Euros", "Pesos Mexicanos", "Yenes", "Wons")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        currencySpinner.adapter = adapter

        // Acción del botón de conversión
        convertButton.setOnClickListener {
            val amount = inputAmount.text.toString().toDoubleOrNull()
            val selectedCurrency = currencySpinner.selectedItem.toString()

            if (amount != null) {
                val result = when (selectedCurrency) {
                    "Dólares" -> convertToDollars(amount)
                    "Euros" -> convertToEuros(amount)
                    "Pesos Mexicanos" -> convertToPesosMx(amount)
                    "Yenes" -> convertToYenes(amount)
                    "Wons" -> convertToWons(amount)
                    else -> 0.0
                }
                resultView.text = "Resultado:\n$selectedCurrency: $result"
            } else {
                resultView.text = "Por favor, ingrese una cantidad válida"
            }
        }
    }

    // Función para convertir Soles a Dólares
    private fun convertToDollars(amount: Double): Double {
        val conversionRate = 0.27  // Ejemplo: 1 Sol = 0.27 USD
        return amount * conversionRate
    }

    // Función para convertir Soles a Euros
    private fun convertToEuros(amount: Double): Double {
        val conversionRate = 0.24  // Ejemplo: 1 Sol = 0.24 EUR
        return amount * conversionRate
    }

    // Función para convertir Soles a Pesos Mexicanos
    private fun convertToPesosMx(amount: Double): Double {
        val conversionRate = 5.28  // Ejemplo: 1 Sol = 5.28 MXN
        return amount * conversionRate
    }

    // Función para convertir Soles a Yenes
    private fun convertToYenes(amount: Double): Double {
        val conversionRate = 38.79  // Ejemplo: 1 Sol = 38,79 JPY
        return amount * conversionRate
    }

    // Función para convertir Soles a Wons
    private fun convertToWons(amount: Double): Double {
        val conversionRate = 355.13  // Ejemplo: 1 Sol = 355,13 KRW
        return amount * conversionRate
    }
}
